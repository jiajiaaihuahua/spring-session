package online.shixun.springtag.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import online.shixun.springtag.model.Member;
import online.shixun.springtag.model.Skill;

/**
 * 会员控制器
 */
@Controller
public class MemberController {

    /**
     * 进入会员注册页面
     * @param model
     * @return
     */
    @RequestMapping(value = "/register", method = RequestMethod.GET)
    public String memberRegisterForm(Model model, @ModelAttribute("member") Member member) {
        model.addAttribute("skillsList", loadAllSkills());
        return "register";
    }

    /**
     * 保存会员注册信息
     * @param model
     * @param member
     * @param file
     * @return
     */
    @RequestMapping(value = "/register/save", method = RequestMethod.POST)
    public String memberRegisterSave(Model model, @ModelAttribute("member") Member member, @RequestParam("picture") MultipartFile file) {
        System.out.println("会员注册信息：" + member);
        System.out.println("上传的图片文件名称：" + member.getPicture().getOriginalFilename());
        System.out.println("上传的图片文件大小：" + member.getPicture().getSize());
        return "redirect:/success.html";
    }

    /**
     * 加载所有待选择技能数据
     * @return
     */
    public List<Skill> loadAllSkills() {
        List<Skill> skillsList = new ArrayList<Skill>();
        skillsList.add(new Skill(1, "Java", "Description Of Java"));
        skillsList.add(new Skill(2, "JavaScript", "Description Of JavaScript"));
        skillsList.add(new Skill(3, "c#", "Description Of c#"));
        skillsList.add(new Skill(4, "Python", "Description Of Python"));
        skillsList.add(new Skill(5, "Android", "Description Of Android"));
        return skillsList;
    }
}
