package online.shixun.springtag.model;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

/**
 * 会员实体类
 */
public class Member {

    private String userName;

    private String hiddenField;

    private String password;

    private String sex;

    private String mainSkill2;

    private List familiarSkills;

    private String selfIntroduction;

    private String mailSkill;

    private String acceptJobType;

    private MultipartFile picture;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getHiddenField() {
        return hiddenField;
    }

    public void setHiddenField(String hiddenField) {
        this.hiddenField = hiddenField;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getMainSkill2() {
        return mainSkill2;
    }

    public void setMainSkill2(String mainSkill2) {
        this.mainSkill2 = mainSkill2;
    }

    public List getFamiliarSkills() {
        return familiarSkills;
    }

    public void setFamiliarSkills(List familiarSkills) {
        this.familiarSkills = familiarSkills;
    }

    public String getSelfIntroduction() {
        return selfIntroduction;
    }

    public void setSelfIntroduction(String selfIntroduction) {
        this.selfIntroduction = selfIntroduction;
    }

    public String getMailSkill() {
        return mailSkill;
    }

    public void setMailSkill(String mailSkill) {
        this.mailSkill = mailSkill;
    }

    public String getAcceptJobType() {
        return acceptJobType;
    }

    public void setAcceptJobType(String acceptJobType) {
        this.acceptJobType = acceptJobType;
    }

    public MultipartFile getPicture() {
        return picture;
    }

    public void setPicture(MultipartFile picture) {
        this.picture = picture;
    }

    @Override
    public String toString() {
        return "Member [userName=" + userName + ", hiddenField=" + hiddenField + ", password=" + password + ", sex=" + sex + ", mainSkill2=" + mainSkill2 + ", familiarSkills=" + familiarSkills + ", selfIntroduction=" + selfIntroduction + ", mailSkill=" + mailSkill + ", acceptJobType=" + acceptJobType + "]";
    }

}
