package online.shixun.springi18n.controllers;

import java.util.Locale;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * 登录控制器
 */
@Controller
public class LoginController {

    /**
     * 进入登录页面
     * @param locale
     * @param model
     * @return
     */
    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String loginPage(Locale locale, Model model) {
        System.out.println("current locale is:" + locale);
        return "login";
    }

    /**
     * 登录成功
     * @param model
     * @param username
     * @return
     */
    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public String welcome(Model model, @RequestParam String username) {
        model.addAttribute("username", username);
        return "welcome";
    }
}
