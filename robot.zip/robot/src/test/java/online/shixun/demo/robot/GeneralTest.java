package online.shixun.demo.robot;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.junit.Test;

public class GeneralTest {
	
	@Test
	public void testJson(){
		double l = Math.random();
		//System.out.println(getWeekOfDate(new Date()));
	}


}
