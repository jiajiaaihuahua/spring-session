/*****************************************************************************
 * Copyright (c) 2015, www.qingshixun.com
 *
 * All rights reserved
 *
 *****************************************************************************/
package online.shixun.project.session1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication // 等同于@Configuration @EnableAutoConfiguration @ComponentScan的组合
public class Application {
	public static void main(String[] args) {
		//启动web
        SpringApplication.run(Application.class, args);
    }
	
}
