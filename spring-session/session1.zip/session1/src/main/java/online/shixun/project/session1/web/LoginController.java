/*****************************************************************************
 * Copyright (c) 2015, www.qingshixun.com
 *
 * All rights reserved
 *
 *****************************************************************************/
package online.shixun.project.session1.web;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class LoginController {
	
	//从classpath中取值，如果没值就赋值默认值为liusijia
	@Value("${name:liusijia}")
	private String name;
	
	@Value("${bookTitle:spring session}")
	private String bookTitle;
	
	@RequestMapping(path="/",method=RequestMethod.GET)
	public String toLogin(Model model,HttpServletRequest request){
		model.addAttribute("name",name);
		model.addAttribute("bookTitle",bookTitle);
		
		//获取session，并且向session中赋值
		request.getSession().setAttribute("user", "qingshixun");
		return "welcome";
	}

}
