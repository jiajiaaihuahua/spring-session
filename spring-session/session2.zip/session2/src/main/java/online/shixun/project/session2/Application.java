/*****************************************************************************
 * Copyright (c) 2015, www.qingshixun.com
 *
 * All rights reserved
 *
 *****************************************************************************/
package online.shixun.project.session2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.embedded.ConfigurableEmbeddedServletContainer;
import org.springframework.boot.context.embedded.EmbeddedServletContainerCustomizer;

@SpringBootApplication // 等同于@Configuration @EnableAutoConfiguration @ComponentScan的组合
public class Application  implements EmbeddedServletContainerCustomizer{
	public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

	/**
	 * 实现 EmbeddedServletContainerCustomizer 接口可以修改tomcat服务器的默认端口号。 
	 */
	@Override
	public void customize(ConfigurableEmbeddedServletContainer container) {
		container.setPort(8090);
		
	}
	
}
