/*****************************************************************************
 * Copyright (c) 2015, www.qingshixun.com
 *
 * All rights reserved
 *
 *****************************************************************************/
package online.shixun.project.session2.config;

import org.springframework.session.jdbc.config.annotation.web.http.EnableJdbcHttpSession;

/**
 * 	The @EnableJdbcHttpSession annotation creates a Spring Bean with the name of springSessionRepositoryFilter 
 * 	that implements Filter. The filter is what is in charge of replacing the HttpSession implementation
 *  to be backed by Spring Session. In this instance Spring Session is backed by a relational database.
 *  
 *  这个注解创建了一个名称为springSessionRepositoryFilter的bean，这个类实现了filter。这个过滤器替换了httpsession的实现
 * @author mrliu
 *
 */
@EnableJdbcHttpSession 
public class HttpSessionConfig {
}

